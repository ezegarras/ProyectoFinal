/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal.dao;

import com.mycompany.proyectofinal.constructor.constructorPaciente;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAO {
    private final String URL = "jdbc:mysql://localhost:3306/la_casa_de_los_lentes";
    private final String USER = "root";
    private final String PASSWORD = "root";

    public void añadirPaciente(constructorPaciente paciente) {
        String query = "INSERT INTO paciente (dniPaciente, nombrePaciente, direccion, telefono, fechaVisita, razonVisita, enfermedades) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, paciente.getDniPaciente());
            stmt.setString(2, paciente.getNombrePaciente());
            stmt.setString(3, paciente.getDireccion());
            stmt.setInt(4, paciente.getTelefono());
            stmt.setString(5, paciente.getFechaVisita());
            stmt.setString(6, paciente.getRazonVisita());
            stmt.setString(7, paciente.getEnfermedades());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ArrayList<constructorPaciente> obtenerPacientes() {
        ArrayList<constructorPaciente> listaPacientes = new ArrayList<>();
        String query = "SELECT * FROM paciente";

        try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                constructorPaciente paciente = new constructorPaciente(
                        rs.getInt("dniPaciente"),
                        rs.getString("nombrePaciente"),
                        rs.getString("direccion"),
                        rs.getInt("telefono"),
                        rs.getString("fechaVisita"),
                        rs.getString("razonVisita"),
                        rs.getString("enfermedades")
                );
                listaPacientes.add(paciente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return listaPacientes;
    }
}