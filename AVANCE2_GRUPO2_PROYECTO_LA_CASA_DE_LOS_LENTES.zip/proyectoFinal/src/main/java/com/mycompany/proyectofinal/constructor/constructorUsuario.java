
package com.mycompany.proyectofinal.constructor;

public class constructorUsuario {
    private String nombreUsuario;
    private String apellidoUsuario;
    private String correo;
    private String contraseña;

    // Constructor
    public constructorUsuario(String nombreUsuario, String apellidoUsuario, String correo, String contraseña) {
        this.nombreUsuario = nombreUsuario;
        this.apellidoUsuario = apellidoUsuario;
        this.correo = correo;
        this.contraseña = contraseña;
    }

    // Getters y Setters
    public String getNombre() {
        return nombreUsuario;
    }

    public void setNombre(String nombre) {
        this.nombreUsuario = nombre;
    }

    public String getApellido() {
        return apellidoUsuario;
    }

    public void setApellido(String apellido) {
        this.apellidoUsuario = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }
}
