/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyectofinal.dao;

import com.mycompany.proyectofinal.constructor.constructorMontura;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MonturaDAO {

    public void insertMontura(constructorMontura montura) {
        String query = "INSERT INTO Montura (codigoMontura, tipoMontura, precio, longitudMontura, anchoPuente, longitudVarilla, longitudLente) "
                     + "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {

            stmt.setInt(1, montura.getCodigoMontura());
            stmt.setString(2, montura.getTipoMontura());
            stmt.setDouble(3, montura.getPrecio());
            stmt.setDouble(4, montura.getLongitudMontura());
            stmt.setDouble(5, montura.getAnchoPuente());
            stmt.setDouble(6, montura.getLongitudVarilla());
            stmt.setDouble(7, montura.getLongitudLente());

            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<constructorMontura> getAllMonturas() {
        List<constructorMontura> monturas = new ArrayList<>();
        String query = "SELECT * FROM Montura";

        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            while (rs.next()) {
                constructorMontura montura = new constructorMontura(
                        rs.getInt("codigoMontura"),
                        rs.getString("tipoMontura"),
                        rs.getDouble("precio"),
                        rs.getDouble("longitudMontura"),
                        rs.getDouble("anchoPuente"),
                        rs.getDouble("longitudVarilla"),
                        rs.getDouble("longitudLente")
                );
                monturas.add(montura);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

        return monturas;
    }
}
